NuclearCraft: Plutonium Age — Resource Pack v1.0.0
==================================================
Compatible with: Minecraft 1.21+ (pack_format 34)
Plugin version:  NuclearCraft v1.0.0 Production

CONTENTS
--------
• 39 custom item models (Plutonium gear, Hazmat, Titan equipment, machines)
• 30 custom sound event declarations (sounds.json)
• Vanilla item overrides via custom_model_data predicates

CUSTOM MODEL DATA RANGES
------------------------
  1001–1019  Plutonium & Hazmat equipment, consumables, materials
  1022–1023  Radiation Antidote, Radiation Serum
  1030–1031  Nuclear Smelter, Nuclear Forge
  1040–1053  Titan Reactor Forge, Titan armor/weapons/materials

ADDING SOUNDS
-------------
Place OGG audio files at:
  assets/nuclearcraft/sounds/<category>/<event_name>.ogg

Categories: radiation, item, ore, machine, upgrade, combat, titan, environment
All sound events are declared in assets/nuclearcraft/sounds.json.

ADDING TEXTURES
---------------
Place PNG textures at:
  assets/nuclearcraft/textures/item/<item_name>.png (16x16 or 32x32)

HOSTING
-------
1. Zip the entire pack folder (not the folder itself, the contents)
2. Host at a public HTTPS URL
3. Generate SHA-1: sha1sum NuclearCraft-ResourcePack-v1.0.0.zip
4. Configure in plugins/NuclearCraft/resourcepack.yml

SUPPORT
-------
See the NuclearCraft-Guide.pdf for full installation instructions.
